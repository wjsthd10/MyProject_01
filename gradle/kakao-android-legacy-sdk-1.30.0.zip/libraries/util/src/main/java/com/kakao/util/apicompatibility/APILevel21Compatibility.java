package com.kakao.util.apicompatibility;

import android.annotation.TargetApi;
import android.os.Build.VERSION_CODES;

/**
 * @author leoshin on 15. 11. 4.
 */
@TargetApi(VERSION_CODES.LOLLIPOP)
class APILevel21Compatibility extends APILevel19Compatibility {
}
