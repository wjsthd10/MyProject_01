/**
 * SDK 내에서 공통으로 사용하는 클래스들을 위한 패키지.
 *
 * Package for classes that are going to be used throughout all modules.
 */
package com.kakao.common;