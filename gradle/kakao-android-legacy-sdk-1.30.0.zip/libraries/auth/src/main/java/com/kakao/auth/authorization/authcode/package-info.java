/**
 * Package related to acquiring authorization code by kakao account authentication / authorization.
 */
package com.kakao.auth.authorization.authcode;
