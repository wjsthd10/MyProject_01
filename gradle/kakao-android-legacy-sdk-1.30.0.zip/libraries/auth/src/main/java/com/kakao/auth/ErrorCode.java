/**
 * Copyright 2014-2016 Kakao Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.kakao.auth;

import android.util.SparseArray;

/**
 * API 요청에 대한 에러 코드
 *
 * This enum class is deprecated. Use {@link ApiErrorCode} instead.
*/
@Deprecated
public enum ErrorCode {

    /**
    * AUTH서버에서 발생하는 에러일때.
    */
    AUTH_ERROR_CODE(-776),
    /**
     * 클라이언트 단에서 http 요청 전,후로 에러 발생한 경우. 대게 인터넷 연결이 끊어진 경우 발생한다. code = -778
     */
    CLIENT_ERROR_CODE(-777),
    /**
    * SDK가 인지 못하고 있는 에러코드
    */
    UNDEFINED_ERROR_CODE(-888),
    /**
    * 서버 내부에서 에러가 발생한 경우. code = -1
    */
    INTERNAL_ERROR_CODE(-1),
    /**
    * 올바르지 않은 파라미터가 전송된 경우. code = -2
    */
    INVALID_PARAM_CODE(-2),
    /**
    * [현재스펙에서는 아직 발생하지 않는다]
    * 카카오계정으로 로그인하지 않고 다른 타입의 계정으로 로그인한 사용자가 카카오서비스(카카오스토리,카카오톡) API를 호출한 경우 또는
    * 해당 API를 개발자 싸이트에서 disable 해놓은 경우. code = -3
    */
    NOT_SUPPORTED_API_CODE(-3),
    /**
    * 계정 제재 또는 contents 제재로 인해 해당 API 호출이 되지 않는 경우. code = -4
    */
    BLOCKED_ACTION_CODE(-4),
    /**
    * API 요청시 권한이 없는 경우. code = -5
    */
    ACCESS_DENIED_CODE(-5),
    /**
    * 삭제 예정 API. 공지사항 참고. code = -9
    */
    DEPRECATED_API(-9),
    /**
    * 허용된 요청 회수가 초과한 경우로 자세한 내용은 쿼터 정책을 참고. code = -10
    */
    EXCEED_LIMIT_CODE(-10),
    /**
    * [로그인기반 API]
    * 해당 앱에 가입되지 않은 사용자가 호출한 경우 발생한다. code = -101
    */
    NOT_REGISTERED_USER_CODE(-101),
    /**
    * [사용자 관리 signup API]
    * 이미 해당 앱에 가입한 유저가 다시 가입 API를 요청한 경우 발생한다. code = -102
    */
    ALREADY_REGISTERED_USER_CODE(-102),
    /**
    * [카카오톡 API]
    * 존재하지 않는 카카오계정으로 요청한 경우 발생한다. code = -103
    */
    NOT_EXIST_KAKAO_ACCOUNT_CODE(-103),
    /**
    * [사용자 관리 me, signup, updateProfile API]
    * 앱에 추가하지 않은 사용자 프로퍼티 키의 값을 불러오거나 저장하려고 한 경우 발생한다.
    * 개발자의 앱 관리 페이지에 등록된 user property key의 이름이 잘못되지 않았는지 확인 필요하다. code = -201
    */
    NOT_REGISTERED_PROPERTY_KEY_CODE(-201),
    /**
    * 등록되지 않은 앱키 또는 앱키로 구성된 access token으로 요청한 경우 발생한다. code = -301
    */
    NOT_EXIST_APP_CODE(-301),
    /**
    * 앱 카테고리가 등록되지 않은 앱으로 요청한 경우 발생한다. code = -302
    */
    NOT_EXIST_APP_CATEGORY_CODE(-302),
    /**
    * [로그인기반 API]
    * 유효하지 않은 앱키 또는 access token으로 요청한 경우 발생한다. code = -401
    */
    INVALID_TOKEN_CODE(-401),
    /**
    * 해당 API에 대한 퍼미션이 없는 앱이 요청한 경우 발생한다. code = -402
    */
    INVALID_SCOPE_CODE(-402),
    /**
     * 등록되지 않은 orgin에서 요청이 들어온 경우. code = -403
     */
    NOT_REGISTERED_ORIGIN_CODE(-403),
    /**
    * 연령인증이 필요한 경우 발생한다. code = -405
    */
    NEED_TO_AGE_AUTHENTICATION(-405),
    /**
    * 앱에 제한된 연령이하가 증명된 사용자가 요청한 경우. (후처리 : 연령인증 페이지를 띄워줘도 통과할 수 없으므로 에러 발생)
    */
    UNDER_AGE_LIMIT(-406),
    /**
    * [카카오톡 API]
    * 카카오톡 미가입 사용자가 요청한 경우 발생한다. code = -501
    */
    NOT_EXIST_KAKAOTALK_USER_CODE(-501),
    /**
    * [카카오톡 API]
    * 지원하지 않는 기기로 메시지를 보내는 경우 발생한다.
    */
    NOT_SUPPORTED_OS(-504),
    /**
    * [카카오톡 API]
    * 받은이가 메시지 수신 거부를 설정한 경우 발생한다. code = -530
    */
    MSG_DISABLED(-530),
    /**
    * [카카오톡 API]
    * 한명이 특정앱에 대해 특정인에게 보낼 수 있는 한달 쿼터 초과시 발생. code = -531
    */
    MSG_SENDER_RECEIVER_MONTHLY(-531),
    /**
    * [카카오톡 API]
    * 한명이 특정앱에 대해 보낼 수 있는 하루 쿼터(받는 사람 관계없이) 초과시 발생. code = -532
    */
    MSG_SENDER_DAILY(-532),
    /**
    * [카카오스토리 API]
    * 카카오스토리 미가입 사용자가 요청한 경우 발생한다. code = -601
    */
    NOT_EXIST_KAKAOSTORY_USER_CODE(-601),
    /**
    * [카카오스토리 upload, postPhoto API]
    * 카카오스토리 이미지 업로드시 max 제한 크기(5M. 단, gif 경우 3M)를 넘을 경우 발생한다. code = -602
    */
    EXCEED_MAX_UPLOAD_SIZE(-602),
    /**
    * [카카오스토리 upload, linkinfo API]
    * 카카오스토리 이미지 업로드/스크랩 정보 요청시 timeout 넘을 경우 발생한다. code = -603
    */
    EXECUTION_TIMED_OUT(-603),
    /**
    * [카카오스토리 postLink API]
    * 스크랩하려는 URL이 scrap 불가능한 경우 발생한다. (404 not found 등) code = -604
    */
    INVALID_STORY_SCRAP_URL(-604),
    /**
    * [카카오스토리 getMyStory API]
    * 카카오스토리 이미지 업로드시 5M 제한 크기를 넘을 경우한다. code = -605
    */
    INVALID_STORY_ACTIVITY_ID(-605),
    /**
    * [카카오스토리 upload, postPhoto API]
    * 업로드 image 갯수가 max값(5개. 단, gif 경우 1개)을 넘을 경우 발생한다.code = -606
    */
    EXCEED_MAX_UPLOAD_NUMBER(-606),
    /**
    * 등록되지 않는 개발자의 앱키 또는 앱키로 구성된 access token으로 요청한 경우 발생한다. code = -701
    */
    NOT_EXIST_DEVELOPER_CODE(-701),
    /**
    * 등록된 푸시토큰이 없는 기기로 푸시 메시지를 보낸 경우 발생한다. code = -901
    */
    NOT_EXIST_PUSH_TOKEN(-901),
    /**
     * 현재 존재하지 않는 개발자가 생성한 앱으로부터 요청이 들어온 경우 code = -903
     */
    DEVELOPER_NOT_EXISTENT_CODE(-903),
    /**
    * friends operation API 요청시 잘못된 friends result id를 사용한 경우
    */
    INVALID_FRIENDS_RESULT_ID(-904),
    /**
    * 카카오서비스가 점검중인 경우로 올바른 요청을 할 수 없는 경우 발생한다. code = -9798
    */
    KAKAO_MAINTENANCE_CODE(-9798);

    private final int errorCode;
    private static final SparseArray<ErrorCode> reverseMap = new SparseArray<ErrorCode>();

    static {
      for (ErrorCode errorCode : ErrorCode.values()) {
         reverseMap.put(errorCode.getErrorCode(), errorCode);
      }
    }

    ErrorCode(final int errorCode) {
    this.errorCode = errorCode;
    }

    /**
    * 숫자로 구성된 에러코드
    * @return 숫자로 구성된 에러코드
    */
    public int getErrorCode() {
      return errorCode;
    }

    /**
    * 숫자 에러코드를 enum으로 변경하여 반환한다.
    * @param i 변경할 숫자 에러코드
    * @return 숫자에 해당하는 enum 에러코드
    */
    public static ErrorCode valueOf(final Integer i) {
      if (i == null)
         return null;
      ErrorCode errorCode = reverseMap.get(i);
      if (errorCode != null)
         return errorCode;
      else
         return UNDEFINED_ERROR_CODE;
    }
}
