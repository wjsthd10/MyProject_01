package com.kakao.plusfriend;

/**
 * @author kevin.kang. Created on 2018. 7. 4..
 */
public class StringSet {
    public static final String app_key = "app_key";
    public static final String kakao_agent = "kakao_agent";
    public static final String api_ver = "api_ver";
    public static final String pf_api_ver = "1.0";
}
