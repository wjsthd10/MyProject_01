/**
 * 카카오톡 API의 응답 클래스들을 위합 패키지.
 *
 * Packages for KakaoTalk API responses.
 */
package com.kakao.kakaotalk.response;