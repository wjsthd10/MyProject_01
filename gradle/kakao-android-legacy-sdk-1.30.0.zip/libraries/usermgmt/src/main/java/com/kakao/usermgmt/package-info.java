/**
 * Provide simple login and user management feature via Kakao account.
 */
package com.kakao.usermgmt;