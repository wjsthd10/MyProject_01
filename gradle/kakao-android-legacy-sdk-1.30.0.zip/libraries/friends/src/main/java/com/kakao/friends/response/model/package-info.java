/**
 * Package containing classes for actual models of friend information.
 */
package com.kakao.friends.response.model;